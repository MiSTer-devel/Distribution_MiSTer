ts-bios-gluk.rom  - ROM with Gluk instead of Basic 128
ts-bios-qc311.rom - ROM with Quick Commander instead of Basic 128
ts-bios-rc196.rom - ROM with Real Commander instead of Basic 128

2 options to use these ROMs (choose only one!):
1) rename the ROM to boot.rom and place to TSConf folder (primary SD card).
2) rename the ROM to tsconf.rom and place to root of primary SD card.
