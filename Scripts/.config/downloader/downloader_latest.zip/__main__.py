import time
start_time = time.monotonic()
from sys import exit
try:
    from downloader.main import main, read_env
except (ImportError, SyntaxError) as e:
    print(e)
    print('\n')
    print('Warning! Your OS version seems to be older than September 2021!')
    print('Please upgrade your OS before running Downloader')
    print('More info at https://github.com/MiSTer-devel/mr-fusion')
    print()
    exit(10)  # Same exit value as: downloader.constants.EXIT_ERROR_WRONG_SETUP
try:
    from commit import default_commit  # type: ignore[import-not-found]
except ImportError as e:
    default_commit = None  # type: ignore[assignment]
if __name__ == '__main__':
    exit_code = main(read_env(default_commit), start_time)
    exit(exit_code)
