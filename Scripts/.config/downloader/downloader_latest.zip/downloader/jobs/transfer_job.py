import io
from typing import Protocol, Union, Optional, Any
from downloader.job_system import Job
class Transferrer(Protocol):
    def transfer(self) -> Union[str, io.BytesIO]:
        ...
    source: str
    calcs: Optional[dict[str, Any]]
    after_job: Optional[Job]
TransferJob = Union[Transferrer, Job]
