from downloader.constants import K_BASE_PATH
from downloader.store_migrator import MigrationBase
from downloader.config import Config
class MigrationV7(MigrationBase):
    def __init__(self, config: Config) -> None:
        self._config = config
    version = 7
    def migrate(self, local_store) -> None:
        for store in local_store['dbs'].values():
            store[K_BASE_PATH] = self._config['base_path']
