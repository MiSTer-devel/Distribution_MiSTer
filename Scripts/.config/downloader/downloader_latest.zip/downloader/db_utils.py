from dataclasses import dataclass
from typing import List, Tuple
from downloader.config import Config, ConfigDatabaseSection, FileChecking
from downloader.constants import DB_STATE_SIGNATURE_NO_HASH, DB_STATE_SIGNATURE_NO_SIZE, DB_STATE_SIGNATURE_NO_TIMESTAMP
from downloader.db_entity import DbEntity
from downloader.local_store_wrapper import DbStateSig
@dataclass
class DbSectionPackage:
    db_id: str
    section: ConfigDatabaseSection
def sorted_db_sections(config: Config) -> List[Tuple[str, ConfigDatabaseSection]]:
    result = []
    first = None
    for db_id, db_section in config['databases'].items():
        if db_id == config['default_db_id']:
            first = (db_id, db_section)
        else:
            result.append((db_id, db_section))
    if first is not None:
        result = [first, *result]
    return result
def build_db_config(input_config: Config, db: DbEntity, ini_description: ConfigDatabaseSection) -> Config:
    result = input_config.copy()
    if db.default_options.filter is not None:
        if 'filter' not in input_config['user_defined_options'] or '[mister]' in db.default_options.filter:
            result['filter'] = db.default_options.filter
    if 'options' in ini_description and ini_description['options'].filter is not None:
        result['filter'] = ini_description['options'].filter
    if result['filter'] is not None:
        result['filter'] = result['filter'].lower()
        if '[mister]' in result['filter']:
            mister_filter = '' if 'filter' not in input_config or input_config['filter'] is None else input_config['filter'].lower()
            result['filter'] = result['filter'].lower().replace('[mister]', mister_filter).strip()
    return result
def can_skip_db(file_checking: FileChecking, sig: DbStateSig, db_hash: str, db_size: int, user_filter: str) -> bool:
    return file_checking == FileChecking.FASTEST \
        and sig['hash'] == db_hash and sig['hash'] != DB_STATE_SIGNATURE_NO_HASH \
        and sig['size'] == db_size and sig['size'] != DB_STATE_SIGNATURE_NO_SIZE \
        and sig['filter'] == user_filter
